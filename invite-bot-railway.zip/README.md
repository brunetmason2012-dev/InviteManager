# Invite Bot - Railway

## Railway setup
1. Upload this project.
2. Add Variables:
   - `DISCORD_TOKEN` = your bot token
   - `CLIENT_ID` = your Discord Application ID
3. Railway runs `npm start`.
4. Enable **Server Members Intent** and **Guild Invites Intent** in the Discord Developer Portal.
5. Give the bot Manage Roles and place its highest role above the autorole.

## Commands
`/setup`
`/invites`
`/invite-info`
`/invite-leaderboard`
`/set-autorole`
`/set-welcome`
`/set-logs`
`/remove-autorole`
`/remove-welcome`
`/remove-logs`

Note: JSON files are local storage. For permanent data across deployments/restarts, attach a Railway Volume or move the data to a database.
