require("dotenv").config();

const {
  Client,
  GatewayIntentBits,
  Partials,
  PermissionsBitField,
  REST,
  Routes,
  SlashCommandBuilder,
  ChannelType
} = require("discord.js");
const fs = require("fs");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildInvites
  ],
  partials: [Partials.GuildMember]
});

const CONFIG_FILE = "./config.json";
const INVITES_FILE = "./invites.json";

function loadJSON(file, fallback = {}) {
  if (!fs.existsSync(file)) {
    fs.writeFileSync(file, JSON.stringify(fallback, null, 2));
    return fallback;
  }
  try {
    return JSON.parse(fs.readFileSync(file, "utf8"));
  } catch {
    return fallback;
  }
}

function saveJSON(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

let configs = loadJSON(CONFIG_FILE);
let inviteData = loadJSON(INVITES_FILE);
const inviteCache = new Map();

const commands = [
  new SlashCommandBuilder()
    .setName("setup")
    .setDescription("Configure the invite bot")
    .addRoleOption(o => o.setName("autorole").setDescription("Automatic role").setRequired(false))
    .addChannelOption(o => o.setName("welcome").setDescription("Welcome channel").addChannelTypes(ChannelType.GuildText).setRequired(false))
    .addChannelOption(o => o.setName("logs").setDescription("Invite log channel").addChannelTypes(ChannelType.GuildText).setRequired(false)),

  new SlashCommandBuilder().setName("invites").setDescription("Check someone's invites")
    .addUserOption(o => o.setName("user").setDescription("User to check").setRequired(false)),

  new SlashCommandBuilder().setName("invite-leaderboard").setDescription("Show the invite leaderboard"),

  new SlashCommandBuilder().setName("invite-info").setDescription("Show detailed invite information")
    .addUserOption(o => o.setName("user").setDescription("User to check").setRequired(false)),

  new SlashCommandBuilder().setName("set-autorole").setDescription("Set the automatic role")
    .addRoleOption(o => o.setName("role").setDescription("Role to give").setRequired(true)),

  new SlashCommandBuilder().setName("set-welcome").setDescription("Set the welcome channel")
    .addChannelOption(o => o.setName("channel").setDescription("Welcome channel").addChannelTypes(ChannelType.GuildText).setRequired(true)),

  new SlashCommandBuilder().setName("set-logs").setDescription("Set the invite log channel")
    .addChannelOption(o => o.setName("channel").setDescription("Log channel").addChannelTypes(ChannelType.GuildText).setRequired(true)),

  new SlashCommandBuilder().setName("remove-autorole").setDescription("Disable automatic role"),
  new SlashCommandBuilder().setName("remove-welcome").setDescription("Disable welcome messages"),
  new SlashCommandBuilder().setName("remove-logs").setDescription("Disable invite logs")
].map(c => c.toJSON());

function getGuildConfig(guildId) {
  if (!configs[guildId]) {
    configs[guildId] = { autorole: null, welcomeChannel: null, logsChannel: null };
    saveJSON(CONFIG_FILE, configs);
  }
  return configs[guildId];
}

function getUserInviteData(guildId, userId) {
  if (!inviteData[guildId]) inviteData[guildId] = {};
  if (!inviteData[guildId][userId]) {
    inviteData[guildId][userId] = { total: 0, left: 0, fake: 0 };
  }
  return inviteData[guildId][userId];
}

async function cacheGuildInvites(guild) {
  try {
    const invites = await guild.invites.fetch();
    const map = new Map();
    invites.forEach(invite => map.set(invite.code, {
      uses: invite.uses || 0,
      inviter: invite.inviter?.id || null
    }));
    inviteCache.set(guild.id, map);
  } catch (e) {
    console.error(`Invite cache failed for ${guild.name}:`, e.message);
  }
}

async function sendLog(guild, message) {
  const config = getGuildConfig(guild.id);
  if (!config.logsChannel) return;
  const channel = guild.channels.cache.get(config.logsChannel);
  if (channel) channel.send(message).catch(() => {});
}

const rest = new REST({ version: "10" }).setToken(process.env.DISCORD_TOKEN);

client.once("ready", async () => {
  console.log(`Logged in as ${client.user.tag}`);
  client.user.setActivity("/invites | Invite Bot", { type: 3 });
  for (const guild of client.guilds.cache.values()) await cacheGuildInvites(guild);
});

client.on("guildCreate", async guild => {
  getGuildConfig(guild.id);
  await cacheGuildInvites(guild);
});

client.on("inviteCreate", invite => cacheGuildInvites(invite.guild));
client.on("inviteDelete", invite => cacheGuildInvites(invite.guild));

client.on("guildMemberAdd", async member => {
  const guild = member.guild;
  const config = getGuildConfig(guild.id);
  let usedInvite = null;

  try {
    const oldInvites = inviteCache.get(guild.id) || new Map();
    const newInvites = await guild.invites.fetch();

    for (const [code, invite] of newInvites) {
      const old = oldInvites.get(code);
      if (old && (invite.uses || 0) > old.uses) {
        usedInvite = invite;
        break;
      }
    }

    const updated = new Map();
    newInvites.forEach(invite => updated.set(invite.code, {
      uses: invite.uses || 0,
      inviter: invite.inviter?.id || null
    }));
    inviteCache.set(guild.id, updated);
  } catch (e) {
    console.error("Invite detection error:", e.message);
  }

  if (config.autorole) {
    const role = guild.roles.cache.get(config.autorole);
    const me = guild.members.me;
    if (role && me && role.position < me.roles.highest.position) {
      await member.roles.add(role).catch(e => console.error("Autorole error:", e.message));
    }
  }

  if (usedInvite?.inviter) {
    const inviter = usedInvite.inviter;
    const data = getUserInviteData(guild.id, inviter.id);
    data.total++;
    saveJSON(INVITES_FILE, inviteData);
    await sendLog(guild,
      `📥 **Member Joined**\n👤 ${member.user.tag}\n🔗 Invited by <@${inviter.id}>\n📊 Total invites: **${data.total}**`
    );
  } else {
    await sendLog(guild, `📥 **Member Joined**\n👤 ${member.user.tag}\n🔗 Inviter: **Unknown**`);
  }

  if (config.welcomeChannel) {
    const channel = guild.channels.cache.get(config.welcomeChannel);
    if (channel) {
      await channel.send(`👋 Welcome ${member} to **${guild.name}**!\nYou are member **#${guild.memberCount}**.`).catch(() => {});
    }
  }
});

client.on("guildMemberRemove", async member => {
  await sendLog(member.guild, `📤 **Member Left**\n👤 ${member.user.tag}\n🆔 ${member.id}`);
});

client.on("interactionCreate", async interaction => {
  if (!interaction.isChatInputCommand() || !interaction.guild) return;

  const guild = interaction.guild;
  const command = interaction.commandName;
  const adminCommands = [
    "setup", "set-autorole", "set-welcome", "set-logs",
    "remove-autorole", "remove-welcome", "remove-logs"
  ];

  if (adminCommands.includes(command) &&
      !interaction.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
    return interaction.reply({ content: "❌ You need **Manage Server** permission.", ephemeral: true });
  }

  if (command === "setup") {
    const config = getGuildConfig(guild.id);
    const role = interaction.options.getRole("autorole");
    const welcome = interaction.options.getChannel("welcome");
    const logs = interaction.options.getChannel("logs");

    if (role) config.autorole = role.id;
    if (welcome) config.welcomeChannel = welcome.id;
    if (logs) config.logsChannel = logs.id;
    saveJSON(CONFIG_FILE, configs);

    return interaction.reply(
      `## ⚙️ Invite Bot Setup\n\n` +
      `👤 **Autorole:** ${config.autorole ? `<@&${config.autorole}>` : "Not set"}\n` +
      `👋 **Welcome:** ${config.welcomeChannel ? `<#${config.welcomeChannel}>` : "Not set"}\n` +
      `📋 **Logs:** ${config.logsChannel ? `<#${config.logsChannel}>` : "Not set"}\n\n✅ Configuration saved.`
    );
  }

  if (command === "set-autorole") {
    const role = interaction.options.getRole("role");
    getGuildConfig(guild.id).autorole = role.id;
    saveJSON(CONFIG_FILE, configs);
    return interaction.reply(`✅ Autorole set to ${role}.`);
  }

  if (command === "remove-autorole") {
    getGuildConfig(guild.id).autorole = null;
    saveJSON(CONFIG_FILE, configs);
    return interaction.reply("✅ Autorole disabled.");
  }

  if (command === "set-welcome") {
    const channel = interaction.options.getChannel("channel");
    getGuildConfig(guild.id).welcomeChannel = channel.id;
    saveJSON(CONFIG_FILE, configs);
    return interaction.reply(`✅ Welcome channel set to ${channel}.`);
  }

  if (command === "remove-welcome") {
    getGuildConfig(guild.id).welcomeChannel = null;
    saveJSON(CONFIG_FILE, configs);
    return interaction.reply("✅ Welcome messages disabled.");
  }

  if (command === "set-logs") {
    const channel = interaction.options.getChannel("channel");
    getGuildConfig(guild.id).logsChannel = channel.id;
    saveJSON(CONFIG_FILE, configs);
    return interaction.reply(`✅ Invite logs set to ${channel}.`);
  }

  if (command === "remove-logs") {
    getGuildConfig(guild.id).logsChannel = null;
    saveJSON(CONFIG_FILE, configs);
    return interaction.reply("✅ Invite logs disabled.");
  }

  if (command === "invites" || command === "invite-info") {
    const user = interaction.options.getUser("user") || interaction.user;
    const data = getUserInviteData(guild.id, user.id);
    const valid = Math.max(0, data.total - data.left - data.fake);

    if (command === "invites") {
      return interaction.reply(
        `## 📊 Invite Stats\n\n👤 **User:** ${user}\n🎟️ **Invites:** ${data.total}\n📤 **Left:** ${data.left}\n🚫 **Fake:** ${data.fake}\n✅ **Valid:** ${valid}`
      );
    }

    return interaction.reply(
      `## 🔎 Invite Information\n\n👤 **User:** ${user}\n🎟️ **Total:** ${data.total}\n📤 **Left:** ${data.left}\n🚫 **Fake:** ${data.fake}\n✅ **Valid:** ${valid}`
    );
  }

  if (command === "invite-leaderboard") {
    const guildInvites = inviteData[guild.id] || {};
    const leaderboard = Object.entries(guildInvites)
      .map(([userId, data]) => ({
        userId,
        valid: Math.max(0, data.total - data.left - data.fake)
      }))
      .sort((a, b) => b.valid - a.valid)
      .slice(0, 10);

    if (!leaderboard.length) return interaction.reply("📊 No invite data yet.");

    let text = "## 🏆 Invite Leaderboard\n\n";
    leaderboard.forEach((u, i) => {
      text += `**${i + 1}.** <@${u.userId}> • **${u.valid}** valid invites\n`;
    });
    return interaction.reply(text);
  }
});

async function start() {
  if (!process.env.DISCORD_TOKEN || !process.env.CLIENT_ID) {
    console.error("❌ Add DISCORD_TOKEN and CLIENT_ID to Railway Variables.");
    process.exit(1);
  }

  try {
    await rest.put(Routes.applicationCommands(process.env.CLIENT_ID), { body: commands });
    console.log("✅ Slash commands registered.");
    await client.login(process.env.DISCORD_TOKEN);
  } catch (e) {
    console.error("❌ Startup error:", e);
    process.exit(1);
  }
}

start();
